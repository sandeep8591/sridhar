package com.cg.lms.presentation;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.lms.exceptions.LMSException;
import com.cg.lms.model.BookDetails;
import com.cg.lms.service.BookService;
import com.cg.lms.service.BookServiceImpl;

public class Main {

	static Logger logger = Logger.getLogger(Main.class);

	public static void main(String[] args) {

		PropertyConfigurator.configure("resources/log4j.properties");
		logger.info("log4j file configured..");

		BookService service = new BookServiceImpl();

		Scanner scanner = null;

		System.out.println("*** welcome to Library Management System *** ");
		System.out.println("1.Add Book");
		System.out.println("2. Select Book by Id");
		System.out.println("3. Select All Books");
		System.out.println("4. exit");

		System.out.println("Ur choice:");
		int input = 0;
		boolean inputFlag = false;

		do {
			scanner = new Scanner(System.in);
			try {

				input = scanner.nextInt();
				inputFlag = true;

				switch (input) {

				case 1:

					scanner.nextLine();
					System.out.println("Enter Book Name:");
					String name = scanner.nextLine();
					System.out.println("Enter Author Name:");
					String author = scanner.nextLine();

					double cost = 0;
					boolean costFlag = false;

					do {
						scanner = new Scanner(System.in);
						System.out.println("Enter Cost:");
						try {
							cost = scanner.nextDouble();
							costFlag = true;
						} catch (InputMismatchException e) {
							costFlag = false;
							System.err.println("salary should contaon  only digits");
						}
					} while (!costFlag);

					scanner.nextLine();

					String publishedDate = "";
					boolean publishFlag = false;
					DateTimeFormatter formatter = null;
					LocalDate localDate = null;

					do {
						scanner = new Scanner(System.in);
						System.out.println("Enter published date (dd-MM-yyyy)");
						publishedDate = scanner.nextLine();
						formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

						try {
							localDate = LocalDate.parse(publishedDate, formatter);
							publishFlag = true;
						} catch (DateTimeException e) {
							publishFlag = false;
							System.err.println("date should be in the given format - (dd-MM-yyyy)");
						}
					} while (!publishFlag);

					BookDetails details = new BookDetails(name, author, cost, localDate);

					try {
						boolean resultFlag = service.validateBookDetails(details);

						if (resultFlag == true) {

							int genId = service.addBook(details);
							System.out.println("book inserted with the given id: " + genId);
						}

					} catch (LMSException e) {
						System.err.println(e.getMessage());
					}

					break;

				case 2:

					break;

				case 3:

					break;

				case 4:
					System.out.println("Thank u, visit again");
					System.exit(0);
					break;

				default:

					inputFlag = false;
					System.out.println("choice from (1-3)");
					break;
				}

			} catch (InputMismatchException e) {
				inputFlag = false;
				System.err.println("enter only digits");
			}

		} while (!inputFlag);

		scanner.close();
	}

}
