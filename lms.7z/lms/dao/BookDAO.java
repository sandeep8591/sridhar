package com.cg.lms.dao;

import com.cg.lms.exceptions.LMSException;
import com.cg.lms.model.BookDetails;

public interface BookDAO {

	int addBookDetails(BookDetails details) throws LMSException;

}
