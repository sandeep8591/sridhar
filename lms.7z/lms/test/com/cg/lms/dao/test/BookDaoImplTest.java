package com.cg.lms.dao.test;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.lms.dao.BookDaoImpl;
import com.cg.lms.exceptions.LMSException;
import com.cg.lms.model.BookDetails;

public class BookDaoImplTest {

	BookDaoImpl daoImpl = null;

	@Before
	public void setUp() throws Exception {
		daoImpl = new BookDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		daoImpl = null;
	}

	@Test
	public void testAddBookDetails() {

		BookDetails details = new BookDetails();
		details.setBookName("java");
		details.setCost(12000d);
		details.setAuthorName("james");
		details.setPublishDate(LocalDate.now());

		try {
			int result = daoImpl.addBookDetails(details);
			assertNotNull(result);
		} catch (LMSException e) {

		}
	}

	@Test
	public void testAddBookDetailsId() {

		BookDetails details = new BookDetails();
		details.setBookName("php");
		details.setCost(14000d);
		details.setAuthorName("satish");
		details.setPublishDate(LocalDate.now());

		try {
			int result = daoImpl.addBookDetails(details);
			assertNull(result);
		} catch (LMSException e) {

		}
	}

}
