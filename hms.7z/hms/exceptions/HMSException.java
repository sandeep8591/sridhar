package com.cg.hms.exceptions;

public class HMSException extends Exception {

	public HMSException(String message) {
		super(message);
	}
}
