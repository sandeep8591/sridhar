package com.cg.service;

import java.util.List;

import com.cg.Exception.CabException;
import com.cg.bean.Cab;

public interface Iservice {
	public List<Cab> getCabDetails();
	public void cabBook(Cab cab);
	void validateName(String name) throws CabException;
	void validateDrop(String drop) throws CabException;
	void validateMobile(String mobile) throws CabException;
	void validatePickup(String pickup) throws CabException;
	void validateCabType(String cabtype) throws CabException;
}
