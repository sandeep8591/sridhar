package com.cg.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.Exception.CabException;
import com.cg.bean.Cab;
import com.cg.dao.DaoImpl;
import com.cg.dao.Idao;


public class ServiceImpl implements Iservice{
Idao id=new DaoImpl();
	@Override
	public List<Cab> getCabDetails() {
		return id.getCabDetails();
		
	}

	@Override
	public void cabBook(Cab cab) {
		id.cabBook(cab);
		
	}
	@Override
	public void validateName(String name) throws CabException {
		String nameRegEx = "[a-zA-Z ]+";
		if (Pattern.matches(nameRegEx, name) == false) {
			throw new CabException("name should contain only alphabets");
		}	
	}

	@Override
	public void validateDrop(String drop) throws CabException{
		String addressRegEx = "[a-zA-Z ]+";
		if (Pattern.matches(addressRegEx, drop) == false) {
			throw new CabException("address should contain only alphabets");
		}
		
	}

	@Override
	public void validateMobile(String mobile)throws CabException {
		String phoneRegEx = "[7|8|9]{1}[0-9]{9}";
		if (Pattern.matches(phoneRegEx, mobile) == false) {
			throw new CabException("mobile number should contain exactly 10 digits");
		}	
	}

	@Override
	public void validateCabType(String cabtype) throws CabException{
		String nameRegEx = "[a-zA-Z ]+";
		if (Pattern.matches(nameRegEx, cabtype) == false) {
			throw new CabException("Enter only alphabets");
		}
	}

	@Override
	public void validatePickup(String pickup) throws CabException {
		String addressRegEx = "[a-zA-Z ]+";
		if (Pattern.matches(addressRegEx, pickup) == false) {
			throw new CabException("address should contain only alphabets");
		
	}
	}
}


	