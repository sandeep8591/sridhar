package com.cg.dao;

import java.util.List;

import com.cg.bean.Cab;
import com.cg.util.CollectionUtil;

public class DaoImpl implements Idao{
CollectionUtil cu=new CollectionUtil();
	@Override
	public List<Cab> getCabDetails() {
		return cu.getCabDetails();
		
	}

	@Override
	public void cabBook(Cab cab) {
		cu.cabBook(cab);
		
	}

}
