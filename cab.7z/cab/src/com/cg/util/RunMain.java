package com.cg.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.Exception.CabException;
import com.cg.bean.Cab;
import com.cg.service.ServiceImpl;

public class RunMain {
	public static void main(String[] args) {
		ServiceImpl si=new ServiceImpl();
		Scanner sc=null;
		String continueChoice ;
		System.out.println("welcome to GoRide");
		do {
		System.out.println("1.Book a Cab\n2:Get Booking Details\n3:exit");
		int choice;
		boolean choiceFlag = false;
		do {
			sc=new Scanner(System.in);
			System.out.println("enter your choice");
			try {
				
				 choice=sc.nextInt();
				choiceFlag = true;
				switch (choice) {
				case 1:
					sc.nextLine();
					String name;
					boolean nameFlag = false;
					do {
						sc = new Scanner(System.in);
						System.out.println("Enter name of the customer");
						name = sc.nextLine();
						try {
							si.validateName(name);
							nameFlag = true;
							break;
						} catch (CabException e) {
							nameFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!nameFlag);
					String pickup;
					boolean pickupFlag = false;
					do {
						sc = new Scanner(System.in);
						System.out.println("Enter pickup location");
						pickup = sc.nextLine();
						try {
							si.validatePickup(pickup);
							pickupFlag = true;
							break;

						} catch (CabException e) {
							pickupFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!pickupFlag);
					String mobile;
					boolean mobileFlag = false;
					do {
						sc = new Scanner(System.in);
						System.out.println("Enter phone number of the customer");
						mobile = sc.nextLine();
						try {
							si.validateMobile(mobile);
							mobileFlag = true;
							break;

						} catch (CabException e) {
							mobileFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!mobileFlag);
					String cabtype;
					boolean cabFlag = false;
					do {
						sc = new Scanner(System.in);
						System.out.println("Enter Cab type");
						cabtype= sc.nextLine();
						try {
							si.validateCabType(cabtype);
							cabFlag = true;
							break;

						} catch (CabException e) {
							cabFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!cabFlag);
					String drop;
					boolean dropFlag=false;
					do {
						sc=new Scanner(System.in);
						System.out.println("enter the Drop location");
						drop=sc.nextLine();
						try {
							si.validateDrop(drop);
							dropFlag=true;
							break;	
						}catch(CabException e) {
							dropFlag=false;
							System.err.println(e.getMessage());		
						}	
					}while(!dropFlag);
					int otp;
					int min=600000;
					int max=699999;
					int range=max-min+1;
					otp=(int) (Math.random()*range)+min;
					Cab cab=new Cab(name, mobile, pickup, drop, cabtype, String.valueOf(otp));
					si.cabBook(cab);
					System.out.println("your OTP is: "+otp);
						break;
				case 2:
					System.out.println(si.getCabDetails());
					break;
				case 3:
					System.out.println("Thank You For Using GoRide");
					System.exit(0);
					break;

				default:
					System.out.println("enter only 1/2/3");;
				}
			}catch(InputMismatchException e)
			{
				choiceFlag = false;
				System.err.println("enter only digits");	
			}
		}while(!choiceFlag);
		
		System.out.println("do u want to continue again(yes/no)");
		continueChoice = sc.next();
		}while(continueChoice.equalsIgnoreCase("yes"));
		
	}

}

