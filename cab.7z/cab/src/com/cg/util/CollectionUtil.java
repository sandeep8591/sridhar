package com.cg.util;

import java.util.ArrayList;
import java.util.List;

import com.cg.bean.Cab;

public class CollectionUtil {
List<Cab> list=new ArrayList<Cab>();
public List<Cab> getCabDetails() {
	return list;
		
	}
public void cabBook(Cab cab) {
	list.add(cab);
	}
}
